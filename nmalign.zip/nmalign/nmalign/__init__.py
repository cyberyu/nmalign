"""forced alignment of lists of string by fuzzy string matching"""

from .lib.align import match

__all__ = ['match']
